﻿Public Class frmSplash


    Private Sub tmrExit_Tick(sender As Object, e As EventArgs) Handles tmrExit.Tick
        Me.Close()

    End Sub
End Class
